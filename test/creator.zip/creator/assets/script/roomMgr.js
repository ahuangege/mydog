var network = require("network");
var main = require("main");
var roomMgr = cc.Class({
    extends: cc.Component,

    properties: {
        chatServers: {
            default: [],
            visible: false
        },
        serverPrefab: cc.Prefab,
        serverParent: cc.Node,
        serverToggleGroup: cc.ToggleGroup,
        roomPrefab: cc.Prefab,
        roomParent: cc.Node,
        roomToggleGroup: cc.ToggleGroup,

    },
    statics: {
        instance: null,
    },

    // use this for initialization
    onLoad: function () {
        roomMgr.instance = this;
        this.nowServerId = "";
        this.nowRoom = null;
    },

    init: function (chatServers) {
        network.addHandler("connector.connectorMain.getChatInfo", this.SVR_getChatInfoBack, this)
        network.addHandler("connector.connectorMain.newRoom", this.SVR_newRoomBack, this)
        network.addHandler("connector.connectorMain.joinRoom", this.SVR_joinRoomBack, this)
        var obj;
        var isFirst = true;
        for (var i = 0; i < chatServers.length; i++) {
            obj = cc.instantiate(this.serverPrefab);
            obj.parent = this.serverParent;
            obj.getComponent("serverPrefab").init(chatServers[i]);
            var toggle = obj.getComponent(cc.Toggle);
            toggle.toggleGroup = this.serverToggleGroup;
            this.serverToggleGroup.addToggle(toggle);
            if (isFirst) {
                isFirst = false;
                toggle.isChecked = true;
                obj.getComponent("serverPrefab").onToggleClick();
            }
        }
    },

    //聊天服务器的选择
    onServerPrefabClick: function (id) {
        this.nowServerId = id;
        this.delChild(this.roomParent);
        network.sendMsg("connector.connectorMain.getChatInfo", { "id": id });
    },

    //房间的选择
    onRoomPrefabClick: function (tmpRoom) {
        this.nowRoom = tmpRoom;
    },


    SVR_getChatInfoBack: function (data) {
        var obj;
        var isFirst = true;
        for (var id in data) {
            obj = cc.instantiate(this.roomPrefab);
            obj.parent = this.roomParent;
            obj.getComponent("roomPrefab").init(data[id]);
            var toggle = obj.getComponent(cc.Toggle);
            toggle.toggleGroup = this.roomToggleGroup;
            this.roomToggleGroup.addToggle(toggle);
            if (isFirst) {
                isFirst = false;
                toggle.isChecked = true;                
                obj.getComponent("roomPrefab").onToggleClick();
            }
        }
    },

    //新建房间
    onNewRoomBtnClick: function () {
        var myName = this.node.getChildByName("myName").getChildByName("myName").getComponent(cc.EditBox).string.trim();
        var roomName = this.node.getChildByName("newRoom").getChildByName("roomName").getComponent(cc.EditBox).string.trim();
        var password = this.node.getChildByName("newRoom").getChildByName("password").getComponent(cc.EditBox).string.trim();
        if (myName === "") {
            main.instance.setWrongInfo("昵称不能为空");
            return;
        }
        if (myName.indexOf(" ") !== -1) {
            main.instance.setWrongInfo("昵称不可包含空格");
            return;
        }
        if (roomName === "") {
            main.instance.setWrongInfo("房间名不能为空");
            return;
        }
        if (roomName.indexOf(" ") !== -1) {
            main.instance.setWrongInfo("房间名不可包含空格");
            return;
        }
        if (password.indexOf(" ") !== -1) {
            main.instance.setWrongInfo("密码不可包含空格");
            return;
        }

        network.sendMsg("connector.connectorMain.newRoom", { "id": this.nowServerId, "myName": myName, "roomName": roomName, "password": password });
    },

    SVR_newRoomBack: function (data) {
        if (data.status === 0) {
            main.instance.showChat(true, data);
            main.instance.showRoomSelect(false);
        }
    },

    //加入房间
    onJoinRoomBtnClick: function () {
        if (!cc.isValid(this.nowRoom)) {
            main.instance.setWrongInfo("房间不存在");
            return;
        }
        var myName = this.node.getChildByName("myName").getChildByName("myName").getComponent(cc.EditBox).string.trim();
        var password = this.node.getChildByName("joinRoom").getChildByName("password").getComponent(cc.EditBox).string.trim();
        if (myName === "") {
            main.instance.setWrongInfo("昵称不能为空");
            return;
        }
        if (myName.indexOf(" ") !== -1) {
            main.instance.setWrongInfo("昵称不可包含空格");
            return;
        }
        if (password.indexOf(" ") !== -1) {
            main.instance.setWrongInfo("密码不可包含空格");
            return;
        }
        if (this.nowRoom.password !== "" && password !== this.nowRoom.password) {
            main.instance.setWrongInfo("密码错误");
            return;
        }
        network.sendMsg("connector.connectorMain.joinRoom", { "id": this.nowServerId, "roomId": this.nowRoom.id, "myName": myName, "password": password });
    },


    SVR_joinRoomBack: function (data) {
        if (data.status === 0) {
            main.instance.showChat(true, data);
            main.instance.showRoomSelect(false);
        } else if (data.status === -1) {
            main.instance.setWrongInfo("密码错误");
        } else if (data.status === -3) {
            main.instance.setWrongInfo("房间不存在");
            this.nowRoom.destroyMyself();
        }
    },

    delChild: function (tmpNode) {
        var child = tmpNode.children;
        for (var i = 0; i < child.length; i++) {
            child[i].destroy();
        }
    },

    onDisable: function () {
        this.delChild(this.roomParent);
        this.delChild(this.serverParent);
    },
});
