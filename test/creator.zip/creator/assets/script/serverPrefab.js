var roomMgr = require("roomMgr");
cc.Class({
    extends: cc.Component,

    properties: {
        serverNameLabel: cc.Label
    },

    // use this for initialization
    init: function (data) {
        this.serverId = data.id;
        this.serverNameLabel.string = data.name;
    },

    onToggleClick: function(){
        roomMgr.instance.onServerPrefabClick(this.serverId);
    }
});
