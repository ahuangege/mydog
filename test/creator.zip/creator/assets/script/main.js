var network = null;
var main = cc.Class({
    extends: cc.Component,

    properties: {
        host: "127.0.0.1",
        port: 4010
    },
    statics: {
        instance: null,
    },

    onLoad: function () {
        main.instance = this;
        this.wrongInfoTimeOut = null;
        network = require("network");
        network.addHandler("gate.main.login", this.SVR_gateLoginBack, this);
        this.wrongInfoLabel = this.node.getChildByName("wrongInfo").getComponent(cc.Label);
    },

    // use this for initialization
    start: function () {
        this.gateConnect();
    },

    onGateOpen: function () {
        network.sendMsg("gate.main.login", "");
    },

    onGateClose: function () {
        this.setWrongInfo("服务器断开！5秒后重连!");
        var self = this;
        setTimeout(function () {
            self.gateConnect();
        }, 5000);
    },

    onConnectorOpen: function () {
        this.showRoomSelect(true);
    },

    onConnectorClose: function () {
        this.showChat(false);
        this.showRoomSelect(false);
        this.gateConnect();
    },

    gateConnect: function () {
        network.connect(this.host, this.port);
        network.on("open", this.onGateOpen, this);
        network.on("close", this.onGateClose, this);
    },


    // called every frame, uncomment this function to activate update callback
    update: function (dt) {
        network.readMsg();
    },

    SVR_gateLoginBack: function (data) {
        network.setRoute(data.route);
        this.chatServers = data.chat;
        var self = this;
        network.connect(data.host, data.port);
        network.on("open", this.onConnectorOpen, this);
        network.on("close", this.onConnectorClose, this);
    },


    setWrongInfo: function (str) {
        clearTimeout(this.wrongInfoTimeOut);
        this.wrongInfoLabel.string = str;
        var self = this;
        this.wrongInfoTimeOut = setTimeout(function () {
            self.wrongInfoLabel.string = "";
        }, 1500);
    },

    showRoomSelect: function (show) {
        var tmpNode = this.node.getChildByName("roomSelect");
        tmpNode.active = show;
        if (show) {
            tmpNode.getComponent("roomMgr").init(this.chatServers);
        }
    },

    showChat: function (show, data) {
        var tmpNode = this.node.getChildByName("chat");
        tmpNode.active = show;
        if (show) {
            tmpNode.getComponent("chatMgr").init(data);
        }
    }

});
