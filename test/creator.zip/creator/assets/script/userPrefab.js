var chatMgr = require("chatMgr");
cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    init: function (data) {
        this.id = data.id;
        this.username = data.name;
        this.node.name = data.id.toString();
        this.node.getChildByName("name").getComponent(cc.Label).string = data.name;
        this.node.getChildByName("id").getComponent(cc.Label).string = "ID:"+ data.id;
    },

    onToggleClick: function(){
        chatMgr.instance.onUserPrefabClick(this);
    },
});
