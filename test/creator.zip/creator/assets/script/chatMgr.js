var network = require("network");
var main = require("main");
var chatMgr = cc.Class({
    extends: cc.Component,

    properties: {
        userParent: cc.Node,
        userPrefab: cc.Prefab,
        userToggleGroup: cc.ToggleGroup,
        chatContent: cc.RichText
    },
    statics: {
        instance: null
    },

    onLoad: function () {
        chatMgr.instance = this;
        this.sendToAll = true;
        this.nowUser = null;
        this.myId = 0;
        this.nowUserLabel = this.node.getChildByName("send").getChildByName("one").getChildByName("name").getComponent(cc.Label);
        this.sendEditBox = this.node.getChildByName("send").getChildByName("content").getComponent(cc.EditBox);
    },

    // use this for initialization
    start: function () {
        network.addHandler("onChat", this.SVR_onChat, this);
        network.addHandler("onNewPlayer", this.SVR_onNewPlayer, this);
        network.addHandler("onLeave", this.SVR_onLeave, this);
    },

    init: function (data) {
        this.chatContent.string = "\n";
        this.myId = data.playerId;
        var obj;
        var players = data.players;
        var isFirst = true;
        for (var id in players) {
            obj = this.newPlayer(players[id]);
            if (id == data.playerId) {
                this.node.getChildByName("info").getChildByName("info").getComponent(cc.Label).string =
                    "我的ID:" + id + "   服务器:" + data.serverName + "   房间ID:" + data.roomId + "   房间名:" + data.roomName;
            }
            if (isFirst) {
                isFirst = false;
                obj.getComponent(cc.Toggle).isChecked = true;
                obj.getComponent("userPrefab").onToggleClick();
            }
        }
    },

    newPlayer: function (player) {
        var obj = cc.instantiate(this.userPrefab);
        obj.parent = this.userParent;
        obj.getComponent("userPrefab").init(player);
        var toggle = obj.getComponent(cc.Toggle);
        toggle.toggleGroup = this.userToggleGroup;
        this.userToggleGroup.addToggle(toggle);
        return obj;
    },

    sendMsg: function () {
        var str = this.sendEditBox.string;
        if (this.sendToAll) {
            network.sendMsg("chat.chatMain.send", { "type": 1, "msg": str });
            this.sendEditBox.string = "";
        } else if (cc.isValid(this.nowUser)) {
            network.sendMsg("chat.chatMain.send", { "type": 2, "msg": str, "to": this.nowUser.id });
            this.sendEditBox.string = "";
        } else {
            main.instance.setWrongInfo("玩家不能为空");
        }
    },

    SVR_onChat: function (data) {
        if (data.type === 1) {
            var str = "";
            if (data.fromId === this.myId) {
                str += "<color=#0C8102>";
            } else {
                str += "<color=#A83AB8>"
            }
            str += data.from + "</c>:" + data.msg + "\n";
            this.chatContent.string += str;
        } else {
            var str = "";
            if (data.fromId === this.myId) {
                str += "<color=#0C8102>";
            } else {
                str += "<color=#A83AB8>"
            }
            str += data.from + "</c><color=FF0000>→</c>";
            if (data.toId === this.myId) {
                str += "<color=#0C8102>";
            } else {
                str += "<color=#A83AB8>";
            }
            str += data.to + "</c>:" + data.msg + "\n";
            this.chatContent.string += str;
        }

        if (this.chatContent.node.height > 2600) {
            var tmpStr = this.chatContent.string.substr(Math.floor(this.chatContent.string.length / 2));
            tmpStr = tmpStr.substr(tmpStr.indexOf("<color"));
            this.chatContent.string = tmpStr;
        }

    },

    SVR_onNewPlayer: function (player) {
        this.newPlayer(player);
    },

    SVR_onLeave: function (msg) {
        var node = this.userParent.getChildByName(msg.id.toString());
        if (cc.isValid(node)) {
            node.destroy();
        }
    },

    onSendToAllToggleClick: function (toggle) {
        this.sendToAll = toggle.isChecked;
    },

    onLeaveBtnClick: function () {
        network.sendMsg("chat.chatMain.leaveRoom", "");
        main.instance.showChat(false);
        main.instance.showRoomSelect(true);
    },

    onUserPrefabClick: function (tmpUser) {
        this.nowUser = tmpUser;
        this.nowUserLabel.string = tmpUser.username;
    },

    delChild: function (tmpNode) {
        var child = tmpNode.children;
        for (var i = 0; i < child.length; i++) {
            child[i].destroy();
        }
    },

    onDisable: function () {
        this.delChild(this.userParent);
        this.chatContent.string = "";
        this.sendEditBox.string = "";
    },
});
