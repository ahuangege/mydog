
var network = module.exports;

var ws = null;
var route = [
    "gate.main.login"
];

var handlers = {};
var msgCache = [];

var tmpBuf = { "len": 0, "buffer": new Uint8Array(0) };

//websocket为应用层协议，没有粘包半包问题。但还是加了4个字节作为长度。

network.connect = function (host, port) {
    network.disconnect();
    tmpBuf = { "len": 0, "buffer": new Uint8Array(0) };
    var url = "ws://" + host + ":" + port;
    ws = new WebSocket(url);
    ws.binaryType = 'arraybuffer';
    ws.onopen = function () {
        msgCache.push({ "id": "open", "data": null })
    };
    ws.onerror = function () { };
    ws.onclose = function () {
        msgCache.push({ "id": "close", "data": null })
    };
    ws.onmessage = function (event) {
        decode(new Uint8Array(event.data));
    };
}

network.on = function (event, cb, self) {
    handlers[event] = cb.bind(self);
}

network.off = function (event) {
    delete handlers[event];
}


network.addHandler = function (cmd, cb, self) {
    network.on(route.indexOf(cmd), cb, self);
}

network.removeHandler = function (cmd) {
    network.off(route.indexOf(cmd));
}


network.setRoute = function (tmpRoute) {
    route = tmpRoute;
}

network.sendMsg = function (cmd, data) {
    var cmdIndex = route.indexOf(cmd);
    var buffer = encode(cmdIndex, data);
    ws.send(buffer);
}

network.readMsg = function () {
    if (msgCache.length > 0) {
        var tmp = msgCache.shift();
        if (handlers[tmp.id]) {
            handlers[tmp.id](tmp.data);
        }
    }
}

network.disconnect = function () {
    if (ws) {
        ws.onopen = function () { };
        ws.onerror = function () { };
        ws.onclose = function () { };
        ws.onmessage = function () { };
        ws.close();
        ws = null;
        tmpBuf.len = 0;
        tmpBuf.buffer = new Uint8Array(0);
        msgCache = [];
    }
}

function encode(cmdIndex, data) {
    data = JSON.stringify(data);
    data = strencode(data);
    var msg_len = data.length + 1;
    var buffer = new Uint8Array(msg_len + 4);
    var index = 0;
    buffer[index++] = (msg_len >> 24) & 0xff;
    buffer[index++] = (msg_len >> 16) & 0xff;
    buffer[index++] = (msg_len >> 8) & 0xff;
    buffer[index++] = msg_len & 0xff;
    buffer[index++] = cmdIndex & 0xff;
    copyArray(buffer, index, data, 0, data.length);
    return buffer;
}

function decode(msg) {
    var readLen = 0;
    while (readLen < msg.length) {
        if (tmpBuf.len === 0) //数据长度未确定
        {
            var newBuf = new Uint8Array(tmpBuf.buffer.length + 1);
            copyArray(newBuf, 0, tmpBuf.buffer, 0, tmpBuf.buffer.length);
            copyArray(newBuf, newBuf.length - 1, [msg[readLen]], 0, 1);
            tmpBuf.buffer = newBuf;
            if (newBuf.length === 4) {
                var index = 0;
                tmpBuf.len = (newBuf[index++] << 24 | newBuf[index++] << 16 | newBuf[index++] << 8 | newBuf[index++]) >>> 0;
                tmpBuf.buffer = new Uint8Array(tmpBuf.len);
            }
            readLen++;
        }
        else if (msg.length - readLen < tmpBuf.len) //数据未全部到达
        {
            copyArray(tmpBuf.buffer, tmpBuf.buffer.length - tmpBuf.len, msg, readLen, msg.length - readLen);
            tmpBuf.len -= (msg.length - readLen);
            readLen = msg.length;
        }
        else {

            copyArray(tmpBuf.buffer, tmpBuf.buffer.length - tmpBuf.len, msg, readLen, tmpBuf.len);
            readLen += tmpBuf.len;
            tmpBuf.len = 0;
            var data = tmpBuf.buffer;
            tmpBuf.buffer = new Uint8Array(0);

            //数据接受完毕，处理数据
            var endBuf = new Uint8Array(data.length - 1);
            copyArray(endBuf, 0, data, 1, data.length - 1);
            msgCache.push({ "id": data[0], "data": JSON.parse(strdecode(endBuf)) })
        }
    }
}

function strencode(str) {
    var byteArray = new Uint8Array(str.length * 3);
    var offset = 0;
    for (var i = 0; i < str.length; i++) {
        var charCode = str.charCodeAt(i);
        var codes = null;
        if (charCode <= 0x7f) {
            codes = [charCode];
        } else if (charCode <= 0x7ff) {
            codes = [0xc0 | (charCode >> 6), 0x80 | (charCode & 0x3f)];
        } else {
            codes = [0xe0 | (charCode >> 12), 0x80 | ((charCode & 0xfc0) >> 6), 0x80 | (charCode & 0x3f)];
        }
        for (var j = 0; j < codes.length; j++) {
            byteArray[offset] = codes[j];
            ++offset;
        }
    }
    var _buffer = new Uint8Array(offset);
    copyArray(_buffer, 0, byteArray, 0, offset);
    return _buffer;
};

function strdecode(bytes) {
    var array = [];
    var offset = 0;
    var charCode = 0;
    var end = bytes.length;
    while (offset < end) {
        if (bytes[offset] < 128) {
            charCode = bytes[offset];
            offset += 1;
        } else if (bytes[offset] < 224) {
            charCode = ((bytes[offset] & 0x3f) << 6) + (bytes[offset + 1] & 0x3f);
            offset += 2;
        } else {
            charCode = ((bytes[offset] & 0x0f) << 12) + ((bytes[offset + 1] & 0x3f) << 6) + (bytes[offset + 2] & 0x3f);
            offset += 3;
        }
        array.push(charCode);
    }
    return String.fromCharCode.apply(null, array);
};

function copyArray(dest, doffset, src, soffset, length) {
    for (var index = 0; index < length; index++) {
        dest[doffset++] = src[soffset++];
    }
};
