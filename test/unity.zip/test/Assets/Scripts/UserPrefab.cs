﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SimpleJSON;

public class UserPrefab : MonoBehaviour {

    [HideInInspector]
    public int id;
    [HideInInspector]
    public string username;

	// Use this for initialization
	public void Init (JSONObject user) {
        id = user["id"];
        username = user["name"];
        transform.name = id.ToString();
        transform.Find("name").GetComponent<Text>().text = user["name"];
        transform.Find("id").GetComponent<Text>().text = "ID:" + user["id"];
	}
	
    public void OnToggleClick(bool isOn)
    {
        if (isOn)
        {
            ChatMgr.instance.OnUserClick(this);
        }
    }
}
