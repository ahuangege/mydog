﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SimpleJSON;

public class RoomMgr : MonoBehaviour
{

    public static RoomMgr instance;
    string nowServerId = "";
    RoomPrefab nowRoom = null;

    public GameObject serverPrefab;
    public Transform serverParent;
    ToggleGroup serverToggleGroup = null;
    public GameObject roomPrefab;
    public Transform roomParent;
    ToggleGroup roomToggleGroup;

    private void Awake()
    {
        instance = this;
        serverToggleGroup = serverParent.GetComponent<ToggleGroup>();
        roomToggleGroup = roomParent.GetComponent<ToggleGroup>();
    }
    // Use this for initialization
    public void Init(JSONArray chatServers)
    {
        SocketClient.AddHandler("connector.connectorMain.getChatInfo", SVR_getChatInfoBack); SocketClient.AddHandler("connector.connectorMain.getChatInfo", SVR_getChatInfoBack);
        SocketClient.AddHandler("connector.connectorMain.newRoom", SVR_newRoomBack);
        SocketClient.AddHandler("connector.connectorMain.joinRoom", SVR_joinRoomBack);
        GameObject obj;
        bool isFirst = true;
        for (int i = 0; i < chatServers.Count; i++)
        {
            obj = Instantiate(serverPrefab);
            obj.transform.SetParent(serverParent);
            obj.GetComponent<ServerPrefab>().init(chatServers[i].AsObject);
            obj.GetComponent<Toggle>().group = serverToggleGroup;
            if (isFirst)
            {
                isFirst = false;
                obj.GetComponent<Toggle>().isOn = true;
            }
        }
    }

    public void OnServerClick(string id)
    {
        nowServerId = id;
        DelChild(roomParent);
        JSONObject tmp = new JSONObject();
        tmp.Add("id", nowServerId);
        SocketClient.SendMsg("connector.connectorMain.getChatInfo", tmp);
    }

    public void OnRoomClick(RoomPrefab tmp)
    {
        nowRoom = tmp;
    }

    void SVR_getChatInfoBack(JSONObject msg)
    {
        GameObject obj;
        bool isFirst = true;
        for (int i = 0; i < msg.Count; i++)
        {
            obj = Instantiate(roomPrefab);
            obj.transform.SetParent(roomParent);
            obj.GetComponent<RoomPrefab>().Init(msg[i].AsObject);
            obj.GetComponent<Toggle>().group = roomToggleGroup;
            if (isFirst)
            {
                isFirst = false;
                obj.GetComponent<Toggle>().isOn = true;
            }
        }
    }

    void SVR_newRoomBack(JSONObject msg)
    {
        if (msg["status"].AsInt == 0)
        {
            Main.instance.ShowRoomSelect(false);
            Main.instance.ShowChat(true, msg);
        }
    }
    void SVR_joinRoomBack(JSONObject msg)
    {
        if (msg["status"].AsInt == 0)
        {
            Main.instance.ShowChat(true, msg);
            Main.instance.ShowRoomSelect(false);
        }
        else if (msg["status"].AsInt == -1)
        {
            Main.instance.setWrongInfo("密码错误");
        }
        else if (msg["status"].AsInt == -3)
        {
            Main.instance.setWrongInfo("房间不存在");
        }
    }

    void DelChild(Transform tmpParent)
    {
        foreach (Transform trsm in tmpParent)
        {
            Destroy(trsm.gameObject);
        }
    }

    public void OnNewRoomBtnClick()
    {
        string myName = transform.Find("myName/myName").GetComponent<InputField>().text.Trim();
        string roomName = transform.Find("newRoom/roomname").GetComponent<InputField>().text.Trim();
        string password = transform.Find("newRoom/password").GetComponent<InputField>().text.Trim();
        if (myName == "")
        {
            Main.instance.setWrongInfo("昵称不能为空");
            return;
        }
        if (myName.Contains(" "))
        {
            Main.instance.setWrongInfo("昵称不可包含空格");
            return;
        }
        if (roomName == "")
        {
            Main.instance.setWrongInfo("房间名不能为空");
            return;
        }
        if (roomName.Contains(" "))
        {
            Main.instance.setWrongInfo("房间名不可包含空格");
            return;
        }
        if (password.Contains(" "))
        {
            Main.instance.setWrongInfo("密码不可包含空格");
            return;
        }
        JSONObject tmp = new JSONObject();
        tmp.Add("id", nowServerId);
        tmp.Add("myName", myName);
        tmp.Add("roomName", roomName);
        tmp.Add("password", password);
        SocketClient.SendMsg("connector.connectorMain.newRoom", tmp);
    }

    public void OnJoinRoomBtnClick()
    {
        if (nowRoom == null)
        {
            Main.instance.setWrongInfo("房间不存在");
            return;
        }
        string myName = transform.Find("myName/myName").GetComponent<InputField>().text.Trim();
        string password = transform.Find("joinRoom/password").GetComponent<InputField>().text.Trim();
        if (myName == "")
        {
            Main.instance.setWrongInfo("昵称不能为空");
            return;
        }
        if (myName.Contains(" "))
        {
            Main.instance.setWrongInfo("昵称不可包含空格");
            return;
        }
        if (password.Contains(" "))
        {
            Main.instance.setWrongInfo("密码不可包含空格");
            return;
        }
        if (nowRoom.password != "" && password != nowRoom.password)
        {
            Main.instance.setWrongInfo("密码错误");
            return;
        }
        JSONObject tmp = new JSONObject();
        tmp.Add("id", nowServerId);
        tmp.Add("myName", myName);
        tmp.Add("roomId", nowRoom.id);
        tmp.Add("password", password);
        SocketClient.SendMsg("connector.connectorMain.joinRoom", tmp);
    }

    private void OnDisable()
    {
        DelChild(roomParent);
        DelChild(serverParent);
    }

}
