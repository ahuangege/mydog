﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using SimpleJSON;
using UnityEngine;

/// <summary>
/// socket静态类
/// </summary>
public static class SocketClient
{
    private static SocketClientChild nowSocket = null;                                                                      //当前socket
    private static List<string> route = new List<string>() { "gate.main.login" };                                           //路由数组
    private static Dictionary<string, Action<JSONObject>> handlers = new Dictionary<string, Action<JSONObject>>();          //路由处理函数
    private static List<SocketMsg> msgCache = new List<SocketMsg>();                                                              //缓存的消息列表

    /// <summary>
    /// 初始化路由信息
    /// </summary>
    /// <param name="routes">路由数组</param>
    public static void InitRoute(List<string> routes)
    {
        route = routes;
    }

    /// <summary>
    /// 注册路由
    /// </summary>
    /// <param name="cmd">路由名称</param>
    /// <param name="handler">路由函数</param>
    public static void AddHandler(string cmd, Action<JSONObject> handler)
    {
        int index = route.IndexOf(cmd);
        if (index == -1)
        {
            Debug.Log("cmd not exists: " + cmd);
            return;
        }
        On(index.ToString(), handler);
    }

    /// <summary>
    /// 移除路由
    /// </summary>
    /// <param name="cmd">路由名称</param>
    public static void RemoveHandler(string cmd)
    {
        int index = route.IndexOf(cmd);
        Off(index.ToString());
    }

    /// <summary>
    /// 注册消息
    /// </summary>
    /// <param name="msgType">消息Id</param>
    /// <param name="handler">消息处理函数</param>
    public static void On(string msgId, Action<JSONObject> handler)
    {
        handlers[msgId] = handler;
    }

    /// <summary>
    /// 移除消息
    /// </summary>
    /// <param name="msgId">消息Id </param>
    public static void Off(string msgId)
    {
        handlers.Remove(msgId);
    }

    /// <summary>
    /// 断开socket连接
    /// </summary>
    public static void DisConnect()
    {
        if (nowSocket != null)
        {
            nowSocket.DisConnect();
        }
    }

    /// <summary>
    /// 连接服务器
    /// </summary>
    /// <param name="host">ip</param>
    /// <param name="port">端口</param>
    public static void Connect(string host, int port)
    {
        DisConnect();
        nowSocket = new SocketClientChild();
        nowSocket.Connect(host, port);
    }

    /// <summary>
    /// 发送消息
    /// </summary>
    /// <param name="cmd">路由名称</param>
    /// <param name="data">数据</param>
    public static void SendMsg(string cmd, JSONObject data)
    {
        int cmdIndex = route.IndexOf(cmd);
        if (cmdIndex == -1)
        {
            Debug.Log("cmd not exists: " + cmd);
            return;
        }
        if (nowSocket != null)
        {
            nowSocket.Send(cmdIndex, data);
        }
    }


    /// <summary>
    /// 读取消息
    /// </summary>
    public static void ReadMsg()
    {
        if (msgCache.Count > 0)
        {
            SocketMsg msg = msgCache[0];
            msgCache.RemoveAt(0);
            if (handlers.ContainsKey(msg.msgId))
            {
                handlers[msg.msgId](msg.msg);
            }
        }
    }


    private class SocketClientChild
    {
        private Socket mySocket = null;         //原生socket
        private bool isDead = false;            //是否已被弃用

        public void DisConnect()
        {
            if (!isDead)
            {
                nowSocket = null;
                isDead = true;
                SocketClose();
                try
                {
                    mySocket.Shutdown(SocketShutdown.Both);
                    mySocket.Close();
                }
                catch (Exception e)
                {
                    Debug.Log(e.ToString());
                }
            }
        }

        public void Send(int cmdIndex, JSONObject data)
        {
            byte[] bytes = Encode(cmdIndex, data);
            try
            {
                mySocket.BeginSend(bytes, 0, bytes.Length, SocketFlags.None, null, null);
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
                SocketClose();
            }
        }

        public void Connect(string host, int port)
        {
            mySocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            mySocket.BeginConnect(host, port, AsyncConnectCallback, mySocket);
        }

        private void AsyncConnectCallback(IAsyncResult result)
        {

            try
            {   // 异步写入结束 
                mySocket.EndConnect(result);
                Recive();
                SocketMsg msg = new SocketMsg();
                msg.msgId = "open";
                pushMsg(msg);
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
                SocketClose();
            }
        }

        private byte[] Encode(int cmd, JSONObject data)
        {
            byte[] byteMsg = Encoding.UTF8.GetBytes(data.ToString());
            int len = byteMsg.Length + 1;
            List<byte> byteSource = new List<byte>();
            byteSource.Add((byte)(len >> 24 & 0xff));
            byteSource.Add((byte)(len >> 16 & 0xff));
            byteSource.Add((byte)(len >> 8 & 0xff));
            byteSource.Add((byte)(len & 0xff));
            byteSource.Add((byte)(cmd & 0xff));
            byteSource.AddRange(byteMsg);
            return byteSource.ToArray();
        }

        private int msgLen = 0;
        private List<byte> msgBytes = new List<byte>();
        private byte[] data = new byte[1024];
        private void Recive()
        {
            try
            {
                //开始接收数据  
                mySocket.BeginReceive(data, 0, data.Length, SocketFlags.None,
                asyncResult =>
                {
                    int length = mySocket.EndReceive(asyncResult);
                    int readLen = 0;
                    while (readLen < length)
                    {
                        if (msgLen == 0)    //数据长度未确定
                        {
                            msgBytes.Add(data[readLen]);
                            if (msgBytes.Count == 4)
                            {
                                msgLen = (msgBytes[0] << 24) | (msgBytes[1] << 16) | (msgBytes[2] << 8) | msgBytes[3];
                                msgBytes.Clear();
                            }
                            readLen++;
                        }
                        else if (length - readLen < msgLen) //数据未全部到达
                        {
                            for (int i = readLen; i < length; i++)
                            {
                                msgBytes.Add(data[i]);
                            }
                            msgLen -= (length - readLen);
                            readLen = length;
                        }
                        else
                        {
                            for (int i = readLen; i < readLen + msgLen; i++)
                            {
                                msgBytes.Add(data[i]);
                            }
                            readLen += msgLen;
                            msgLen = 0;
                            List<byte> tmpBytes = msgBytes;
                            msgBytes = new List<byte>();

                            //数据接收完毕，缓存数据
                            SocketMsg msg = new SocketMsg();
                            msg.msgId = tmpBytes[0].ToString();
                            msg.msg = JSONObject.Parse(Encoding.UTF8.GetString(tmpBytes.GetRange(1, tmpBytes.Count - 1).ToArray())).AsObject;
                            pushMsg(msg);
                        }
                    }

                    Recive();
                }, null);
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
                SocketClose();
            }
        }


        private void SocketClose()
        {
            if (!isDead)
            {
                SocketMsg msg = new SocketMsg();
                msg.msgId = "close";
                pushMsg(msg);
                DisConnect();
            }
        }
        private void pushMsg(SocketMsg msg)
        {
            msgCache.Add(msg);
        }
    }

    //接收到的消息结构
    private class SocketMsg
    {
        public string msgId = "";
        public JSONObject msg = null;
    }
}
