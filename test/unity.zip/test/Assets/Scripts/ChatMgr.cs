﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SimpleJSON;

public class ChatMgr : MonoBehaviour
{
    public static ChatMgr instance;

    public Transform userParent;
    public GameObject userPrefab;
    ToggleGroup userToggleGroup;
    public Text chatContent;

    bool sendToAll = true;
    UserPrefab nowUser = null;
    int myId = 0;
    Text nowUserText = null;
    InputField sendInputField = null;

    private void Awake()
    {
        instance = this;
        nowUserText = transform.Find("send/one").GetComponent<Text>();
        sendInputField = transform.Find("send/content").GetComponent<InputField>();
        userToggleGroup = userParent.GetComponent<ToggleGroup>();
    }

    // Use this for initialization
    void Start()
    {
        SocketClient.AddHandler("onChat", SVR_onChat);
        SocketClient.AddHandler("onNewPlayer", SVR_onNewPlayer);
        SocketClient.AddHandler("onLeave", SVR_onLeave);

    }

    public void Init(JSONObject data)
    {
        sendInputField.text = "";
        chatContent.text = "\n";
        myId = data["playerId"];

        GameObject obj;
        JSONNode players = data["players"];
        bool isFirst = true;
        for (int i = 0; i < players.Count; i++)
        {
            obj = newPlayer(players[i].AsObject);
            if (players[i]["id"].AsInt == data["playerId"].AsInt)
            {
                transform.Find("info/info").GetComponent<Text>().text =
                    "我的ID:" + data["playerId"] + "  服务器:" + data["serverName"] + "  房间ID:" + data["roomId"] + "  房间名:" + data["roomName"];
            }
            if (isFirst)
            {
                isFirst = false;
                obj.GetComponent<Toggle>().isOn = true;
            }
        }

    }

    GameObject newPlayer(JSONObject player)
    {
        GameObject obj = Instantiate(userPrefab);
        obj.transform.SetParent(userParent);
        obj.GetComponent<UserPrefab>().Init(player);
        obj.GetComponent<Toggle>().group = userToggleGroup;
        return obj;
    }

    void SVR_onChat(JSONObject msg)
    {
        if (msg["type"].AsInt == 1)
        {
            string str = "";
            if (msg["fromId"] == myId)
            {
                str += "<color=#0C8102>";
            }
            else
            {
                str += "<color=#A83AB8>";
            }
            str += msg["from"] + "</color>:" + msg["msg"] + "\n";
            chatContent.text += str;
        }
        else
        {
            string str = "";
            if (msg["fromId"] == myId)
            {
                str += "<color=#0C8102>";
            }
            else
            {
                str += "<color=#A83AB8>";
            }
            str += msg["from"] + "</color><color=#FF0000>→</color>";
            if (msg["toId"] == myId)
            {
                str += "<color=#0C8102>";
            }
            else
            {
                str += "<color=#A83AB8>";
            }
            str += msg["to"] + "</color>:" + msg["msg"] + "\n";
            chatContent.text += str;
        }

        if (chatContent.GetComponent<RectTransform>().sizeDelta.y > 2600)
        {
            string tmpText = chatContent.text.Substring(Mathf.FloorToInt(chatContent.text.Length / 2));
            tmpText = tmpText.Substring(tmpText.IndexOf("<color"));
            chatContent.text = tmpText;
        }
    }

    void SVR_onNewPlayer(JSONObject msg)
    {
        newPlayer(msg);
    }

    void SVR_onLeave(JSONObject msg)
    {
        Destroy(userParent.Find(msg["id"]).gameObject);
    }

    public void Send()
    {
        string str = sendInputField.text;
        sendInputField.text = "";
        JSONObject tmp = new JSONObject();
        if (sendToAll)
        {
            tmp.Add("type", 1);
            tmp.Add("msg", str);
            SocketClient.SendMsg("chat.chatMain.send", tmp);
        }
        else if (nowUser != null)
        {
            tmp.Add("type", 2);
            tmp.Add("to", nowUser.id);
            tmp.Add("msg", str);
            SocketClient.SendMsg("chat.chatMain.send", tmp);
        }
        else
        {
            Main.instance.setWrongInfo("玩家不能为空");
        }
    }

    public void OnUserClick(UserPrefab tmp)
    {
        nowUser = tmp;
        nowUserText.text = tmp.username;
    }

    public void OnSendToAllClick(bool isOn)
    {
        sendToAll = isOn;
    }

    public void OnLeaveBtnClick()
    {
        SocketClient.SendMsg("chat.chatMain.leaveRoom", new JSONObject());
        Main.instance.ShowChat(false);
        Main.instance.ShowRoomSelect(true);
    }

    void DelChild(Transform tmpParent)
    {
        foreach (Transform trsm in tmpParent)
        {
            Destroy(trsm.gameObject);
        }
    }

    private void OnDisable()
    {
        DelChild(userParent);
        chatContent.text = "";
        sendInputField.text = "";
    }
}
