﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using SimpleJSON;

public class Main : MonoBehaviour
{

    public static Main instance;
    private Text wrongInfoText;
    private Coroutine wrongInfoTimeout = null;
    JSONArray chatServers = null;
    Transform roomSelectPanel = null;
    Transform chatPanel = null;
    public string host = "127.0.0.1";
    public int port = 4010;

    void Awake()
    {
        instance = this;
    }

    // Use this for initialization
    void Start()
    {
        SocketClient.AddHandler("gate.main.login", SVR_gateLoginBack);
        wrongInfoText = transform.Find("wrongInfo").GetComponent<Text>();
        roomSelectPanel = transform.Find("roomSelect");
        chatPanel = transform.Find("chat");
        StartCoroutine(GateConnect(0f));
    }



    void OnGateOpen(JSONObject msg)
    {
        SocketClient.SendMsg("gate.main.login", new JSONObject());
    }
    void OnGateClose(JSONObject msg)
    {
        setWrongInfo("服务器断开！5秒后重连！");
        StartCoroutine(GateConnect(5f));
    }

    void OnConnectorOpen(JSONObject msg)
    {
        ShowRoomSelect(true);
    }

    void OnConnectorClose(JSONObject msg)
    {
        ShowChat(false);
        ShowRoomSelect(false);
        StartCoroutine(GateConnect(0));
    }



    void SVR_gateLoginBack(JSONObject msg)
    {
        List<string> tmpRoute = new List<string>();
        for (int i = 0; i < msg["route"].Count; i++)
        {
            tmpRoute.Add(msg["route"][i]);
        }
        SocketClient.InitRoute(tmpRoute);
        chatServers = msg["chat"].AsArray;
        SocketClient.Connect(msg["host"], msg["port"]);
        SocketClient.On("open", OnConnectorOpen);
        SocketClient.On("close", OnConnectorClose);
    }


    IEnumerator GateConnect(float time)
    {
        yield return new WaitForSeconds(time);
        SocketClient.Connect(host, port);
        SocketClient.On("open", OnGateOpen);
        SocketClient.On("close", OnGateClose);
    }


    public void ShowRoomSelect(bool show)
    {
        roomSelectPanel.gameObject.SetActive(show);
        if (show)
        {
            RoomMgr.instance.Init(chatServers);
        }
    }

    public void ShowChat(bool show, JSONObject data = null)
    {
        chatPanel.gameObject.SetActive(show);
        if (show)
        {
            ChatMgr.instance.Init(data);
        }
    }

    public void setWrongInfo(string info)
    {
        if (wrongInfoTimeout != null)
        {
            StopCoroutine(wrongInfoTimeout);
        }
        wrongInfoText.text = info;
        wrongInfoTimeout = StartCoroutine("wrongInfoDisappear");
    }

    IEnumerator wrongInfoDisappear()
    {
        yield return new WaitForSeconds(1.5f);
        wrongInfoText.text = "";
    }

    // Update is called once per frame
    void Update()
    {
        SocketClient.ReadMsg();
    }


}
