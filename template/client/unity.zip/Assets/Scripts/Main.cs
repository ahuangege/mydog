﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Main : MonoBehaviour
{

    public static Main instance;
    private Text wrongInfoText;
    private Coroutine wrongInfoTimeout = null;
    Proto.server_info[] chatServers = null;
    Transform roomSelectPanel = null;
    Transform chatPanel = null;
    public string host = "127.0.0.1";
    public int port = 4010;

    void Awake()
    {
        instance = this;
    }

    // Use this for initialization
    void Start()
    {
        wrongInfoText = transform.Find("wrongInfo").GetComponent<Text>();
        roomSelectPanel = transform.Find("roomSelect");
        chatPanel = transform.Find("chat");
        StartCoroutine(GateConnect(0f));
    }

    

    void OnGateOpen(string msg)
    {
        SocketClient.AddHandler("gate.main.login", SVR_gateLoginBack);
        SocketClient.SendMsg("gate.main.login");
    }
    void OnGateClose(string msg)
    {
        setWrongInfo("服务器断开！5秒后重连！");
        StartCoroutine(GateConnect(5f));
    }

    void OnConnectorOpen(string msg)
    {
        ShowRoomSelect(true);
    }

    void OnConnectorClose(string msg)
    {
        ShowChat(false);
        ShowRoomSelect(false);
        StartCoroutine(GateConnect(0));
    }

    void SVR_gateLoginBack(string msg)
    {
        Proto.gate_main_login_rsp back_msg = JsonUtility.FromJson<Proto.gate_main_login_rsp>(msg);
        chatServers = back_msg.chat;
        SocketClient.Connect(back_msg.host, back_msg.port);
        SocketClient.OnOpen(OnConnectorOpen);
        SocketClient.OnClose(OnConnectorClose);
    }


    IEnumerator GateConnect(float time)
    {
        yield return new WaitForSeconds(time);
        SocketClient.Connect(host, port);
        SocketClient.OnOpen(OnGateOpen);
        SocketClient.OnClose(OnGateClose);
    }


    public void ShowRoomSelect(bool show)
    {
        roomSelectPanel.gameObject.SetActive(show);
        if (show)
        {
            RoomMgr.instance.Init(chatServers);
        }
    }

    public void ShowChat(bool show, Proto.join_room_rsp data = null)
    {
        chatPanel.gameObject.SetActive(show);
        if (show)
        {
            ChatMgr.instance.Init(data);
        }
    }

    public void setWrongInfo(string info)
    {
        if (wrongInfoTimeout != null)
        {
            StopCoroutine(wrongInfoTimeout);
        }
        wrongInfoText.text = info;
        wrongInfoTimeout = StartCoroutine("wrongInfoDisappear");
    }

    IEnumerator wrongInfoDisappear()
    {
        yield return new WaitForSeconds(1.5f);
        wrongInfoText.text = "";
    }

    // Update is called once per frame
    void Update()
    {
        SocketClient.ReadMsg();
    }

    private void OnApplicationQuit()
    {
        SocketClient.DisConnect();
    }

}
