﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RoomPrefab : MonoBehaviour
{

    [HideInInspector]
    public int id;
    [HideInInspector]
    public string password;
    // Use this for initialization
    public void Init(Proto.room_info room)
    {
        id = room.id;
        password = room.password;
        transform.Find("name").GetComponent<Text>().text = room.name;
        transform.Find("id").GetComponent<Text>().text = "ID:" + room.id;
    }

    public void DestroyMyself()
    {
        Destroy(gameObject);
    }

    public void OnToggleClick(bool isOn)
    {
        if (isOn)
        {
            RoomMgr.instance.OnRoomClick(this);
        }
    }
}
