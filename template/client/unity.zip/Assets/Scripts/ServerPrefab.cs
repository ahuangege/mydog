﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ServerPrefab : MonoBehaviour
{
    string serverId = "";
    bool nowIsOn = false;
    // Use this for initialization
    public void init(Proto.server_info server)
    {
        serverId = server.id;
        transform.Find("name").GetComponent<Text>().text = server.name;
    }

    // Update is called once per frame
    public void OnToggleClick(bool isOn)
    {
        if (nowIsOn != isOn)
        {
            nowIsOn = isOn;
        }
        else
        {
            return;
        }
        if (isOn)
        {
            RoomMgr.instance.OnServerClick(serverId);
        }
    }
}
