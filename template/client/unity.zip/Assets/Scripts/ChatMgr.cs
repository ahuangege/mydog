﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChatMgr : MonoBehaviour
{
    public static ChatMgr instance;

    public Transform userParent;
    public GameObject userPrefab;
    ToggleGroup userToggleGroup;
    public Text chatContent;

    bool sendToAll = true;
    UserPrefab nowUser = null;
    int myId = 0;
    Text nowUserText = null;
    InputField sendInputField = null;

    private void Awake()
    {
        instance = this;
        nowUserText = transform.Find("send/one").GetComponent<Text>();
        sendInputField = transform.Find("send/content").GetComponent<InputField>();
        userToggleGroup = userParent.GetComponent<ToggleGroup>();
    }

    // Use this for initialization
    void Start()
    {
        SocketClient.AddHandler("onChat", SVR_onChat);
        SocketClient.AddHandler("onNewPlayer", SVR_onNewPlayer);
        SocketClient.AddHandler("onLeave", SVR_onLeave);

    }

    public void Init(Proto.join_room_rsp data)
    {
        sendInputField.text = "";
        chatContent.text = "\n";
        myId = data.playerId;

        GameObject obj;
        Proto.player_info[] players = data.players;
        bool isFirst = true;
        for (int i = 0; i < players.Length; i++)
        {
            obj = newPlayer(players[i]);
            if (players[i].id == data.playerId)
            {
                transform.Find("info/info").GetComponent<Text>().text =
                    "我的ID:" + data.playerId + "  服务器:" + data.serverName + "  房间ID:" + data.roomId + "  房间名:" + data.roomName;
            }
            if (isFirst)
            {
                isFirst = false;
                obj.GetComponent<Toggle>().isOn = true;
            }
        }

    }

    GameObject newPlayer(Proto.player_info player)
    {
        GameObject obj = Instantiate(userPrefab);
        obj.transform.SetParent(userParent);
        obj.GetComponent<UserPrefab>().Init(player);
        obj.GetComponent<Toggle>().group = userToggleGroup;
        return obj;
    }

    void SVR_onChat(string _msg)
    {
        Proto.on_chat msg = JsonUtility.FromJson<Proto.on_chat>(_msg);
        if (msg.type == 1)
        {
            string str = "";
            if (msg.fromId == myId)
            {
                str += "<color=#0C8102>";
            }
            else
            {
                str += "<color=#A83AB8>";
            }
            str += msg.from + "</color>:" + msg.msg + "\n";
            chatContent.text += str;
        }
        else
        {
            string str = "";
            if (msg.fromId == myId)
            {
                str += "<color=#0C8102>";
            }
            else
            {
                str += "<color=#A83AB8>";
            }
            str += msg.from + "</color><color=#FF0000>→</color>";
            if (msg.toId == myId)
            {
                str += "<color=#0C8102>";
            }
            else
            {
                str += "<color=#A83AB8>";
            }
            str += msg.to + "</color>:" + msg.msg + "\n";
            chatContent.text += str;
        }

        if (chatContent.GetComponent<RectTransform>().sizeDelta.y > 2600)
        {
            string tmpText = chatContent.text.Substring(Mathf.FloorToInt(chatContent.text.Length / 2));
            tmpText = tmpText.Substring(tmpText.IndexOf("<color"));
            chatContent.text = tmpText;
        }
    }

    void SVR_onNewPlayer(string msg)
    {
        Proto.player_info tmp = JsonUtility.FromJson<Proto.player_info>(msg);
        newPlayer(tmp);
    }

    void SVR_onLeave(string msg)
    {
        Proto.on_leave tmp = JsonUtility.FromJson<Proto.on_leave>(msg);
        Destroy(userParent.Find(tmp.id.ToString()).gameObject);
    }

    public void Send()
    {
        string str = sendInputField.text;
        sendInputField.text = "";
        Proto.chat_chatMain_send_req tmp = new Proto.chat_chatMain_send_req();
        if (sendToAll)
        {
            tmp.type = 1;
            tmp.msg = str;
            SocketClient.SendMsg("chat.chatMain.send", tmp);
        }
        else if (nowUser != null)
        {
            tmp.type = 2;
            tmp.toId = nowUser.id;
            tmp.msg = str;
            SocketClient.SendMsg("chat.chatMain.send", tmp);
        }
        else
        {
            Main.instance.setWrongInfo("玩家不能为空");
        }
    }

    public void OnUserClick(UserPrefab tmp)
    {
        nowUser = tmp;
        nowUserText.text = tmp.username;
    }

    public void OnSendToAllClick(bool isOn)
    {
        sendToAll = isOn;
    }

    public void OnLeaveBtnClick()
    {
        SocketClient.SendMsg("chat.chatMain.leaveRoom");
        Main.instance.ShowChat(false);
        Main.instance.ShowRoomSelect(true);
    }

    void DelChild(Transform tmpParent)
    {
        foreach (Transform trsm in tmpParent)
        {
            Destroy(trsm.gameObject);
        }
    }

    private void OnDisable()
    {
        DelChild(userParent);
        chatContent.text = "";
        sendInputField.text = "";
    }
}
