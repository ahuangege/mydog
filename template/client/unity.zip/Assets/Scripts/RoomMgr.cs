﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RoomMgr : MonoBehaviour
{

    public static RoomMgr instance;
    string nowServerId = "";
    RoomPrefab nowRoom = null;

    public GameObject serverPrefab;
    public Transform serverParent;
    ToggleGroup serverToggleGroup = null;
    public GameObject roomPrefab;
    public Transform roomParent;
    ToggleGroup roomToggleGroup;

    private void Awake()
    {
        instance = this;
        serverToggleGroup = serverParent.GetComponent<ToggleGroup>();
        roomToggleGroup = roomParent.GetComponent<ToggleGroup>();
    }
    // Use this for initialization
    public void Init(Proto.server_info[] chatServers)
    {
        SocketClient.AddHandler("connector.connectorMain.getChatInfo", SVR_getChatInfoBack);
        SocketClient.AddHandler("connector.connectorMain.newRoom", SVR_newRoomBack);
        SocketClient.AddHandler("connector.connectorMain.joinRoom", SVR_joinRoomBack);
        GameObject obj;
        bool isFirst = true;
        for (int i = 0; i < chatServers.Length; i++)
        {
            obj = Instantiate(serverPrefab);
            obj.transform.SetParent(serverParent);
            obj.GetComponent<ServerPrefab>().init(chatServers[i]);
            obj.GetComponent<Toggle>().group = serverToggleGroup;
            if (isFirst)
            {
                isFirst = false;
                obj.GetComponent<Toggle>().isOn = true;
            }
        }
    }

    public void OnServerClick(string id)
    {
        nowServerId = id;
        DelChild(roomParent);
        Proto.server_info tmp_info = new Proto.server_info();
        tmp_info.id = nowServerId;
        SocketClient.SendMsg("connector.connectorMain.getChatInfo", tmp_info);
    }

    public void OnRoomClick(RoomPrefab tmp)
    {
        nowRoom = tmp;
    }

    void SVR_getChatInfoBack(string back_msg)
    {
        Proto.room_info[] msg = JsonUtility.FromJson<Proto.connector_connectorMain_getChatInfo_rsp>(back_msg).rooms;
        GameObject obj;
        bool isFirst = true;
        for (int i = 0; i < msg.Length; i++)
        {
            obj = Instantiate(roomPrefab);
            obj.transform.SetParent(roomParent);
            obj.GetComponent<RoomPrefab>().Init(msg[i]);
            obj.GetComponent<Toggle>().group = roomToggleGroup;
            if (isFirst)
            {
                isFirst = false;
                obj.GetComponent<Toggle>().isOn = true;
            }
        }
    }

    void SVR_newRoomBack(string back_msg)
    {
        Proto.join_room_rsp msg = JsonUtility.FromJson<Proto.join_room_rsp>(back_msg);
        if (msg.status == 0)
        {
            Main.instance.ShowRoomSelect(false);
            Main.instance.ShowChat(true, msg);
        }
    }
    void SVR_joinRoomBack(string back_msg)
    {
        Proto.join_room_rsp msg = JsonUtility.FromJson<Proto.join_room_rsp>(back_msg);
        if (msg.status == 0)
        {
            Main.instance.ShowChat(true, msg);
            Main.instance.ShowRoomSelect(false);
        }
        else if (msg.status == -1)
        {
            Main.instance.setWrongInfo("密码错误");
        }
        else if (msg.status == -3)
        {
            Main.instance.setWrongInfo("房间不存在");
        }
    }

    void DelChild(Transform tmpParent)
    {
        foreach (Transform trsm in tmpParent)
        {
            Destroy(trsm.gameObject);
        }
    }

    public void OnNewRoomBtnClick()
    {
        string myName = transform.Find("myName/myName").GetComponent<InputField>().text.Trim();
        string roomName = transform.Find("newRoom/roomname").GetComponent<InputField>().text.Trim();
        string password = transform.Find("newRoom/password").GetComponent<InputField>().text.Trim();
        if (myName == "")
        {
            Main.instance.setWrongInfo("昵称不能为空");
            return;
        }
        if (myName.Contains(" "))
        {
            Main.instance.setWrongInfo("昵称不可包含空格");
            return;
        }
        if (roomName == "")
        {
            Main.instance.setWrongInfo("房间名不能为空");
            return;
        }
        if (roomName.Contains(" "))
        {
            Main.instance.setWrongInfo("房间名不可包含空格");
            return;
        }
        if (password.Contains(" "))
        {
            Main.instance.setWrongInfo("密码不可包含空格");
            return;
        }
        Proto.connector_connectorMain_newRoom_req tmp = new Proto.connector_connectorMain_newRoom_req();
        tmp.id = nowServerId;
        tmp.myName = myName;
        tmp.roomName = roomName;
        tmp.password = password;
        SocketClient.SendMsg("connector.connectorMain.newRoom", tmp);
    }

    public void OnJoinRoomBtnClick()
    {
        if (nowRoom == null)
        {
            Main.instance.setWrongInfo("房间不存在");
            return;
        }
        string myName = transform.Find("myName/myName").GetComponent<InputField>().text.Trim();
        string password = transform.Find("joinRoom/password").GetComponent<InputField>().text.Trim();
        if (myName == "")
        {
            Main.instance.setWrongInfo("昵称不能为空");
            return;
        }
        if (myName.Contains(" "))
        {
            Main.instance.setWrongInfo("昵称不可包含空格");
            return;
        }
        if (password.Contains(" "))
        {
            Main.instance.setWrongInfo("密码不可包含空格");
            return;
        }
        if (nowRoom.password != "" && password != nowRoom.password)
        {
            Main.instance.setWrongInfo("密码错误");
            return;
        }
        Proto.connector_connectorMain_joinRoom_req tmp = new Proto.connector_connectorMain_joinRoom_req();
        tmp.id = nowServerId;
        tmp.myName = myName;
        tmp.roomId = nowRoom.id;
        tmp.password = password;
        SocketClient.SendMsg("connector.connectorMain.joinRoom", tmp);
    }

    private void OnDisable()
    {
        DelChild(roomParent);
        DelChild(serverParent);
    }

}
