﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace Proto
{
    [Serializable]
    public class gate_main_login_rsp
    {
        public string host;
        public int port;
        public server_info[] chat;
    }

    [Serializable]
    public class server_info
    {
        public string id;
        public string name;
    }

    [Serializable]
    public class connector_connectorMain_getChatInfo_rsp
    {
        public room_info[] rooms;
    }

    [Serializable]
    public class room_info
    {
        public int id;
        public string name;
        public string password;
    }

    [Serializable]
    public class connector_connectorMain_newRoom_req
    {
        public string id;
        public string myName;
        public string roomName;
        public string password;
    }

    [Serializable]
    public class connector_connectorMain_joinRoom_req
    {
        public string id;
        public string myName;
        public int roomId;
        public string password;
    }

    [Serializable]
    public class join_room_rsp
    {
        public int status;
        public string roomName;
        public int roomId;
        public int playerId;
        public string serverId;
        public string serverName;
        public player_info[] players;
    }

    [Serializable]
    public class player_info
    {
        public int id;
        public int uid;
        public string sid;
        public string name;
    }

    [Serializable]
    public class chat_chatMain_send_req
    {
        public int type;
        public int toId;
        public string msg;
    }

    [Serializable]
    public class on_chat
    {
        public int type;
        public string msg;
        public int fromId;
        public string from;
        public int toId;
        public string to;
    }

    [Serializable]
    public class on_leave
    {
        public int id;
    }
}