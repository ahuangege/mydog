
var network = module.exports;

var ws = null;
var route = [];
var heartbeatTimer = null;
var heartbeatResTimeoutTimer = null;

var handlers = {};
var msgCache = [];
var openOrClose = { "open": -1, "close": -2 };
var tmpBuf = { "len": 0, "buffer": new Uint8Array(0) };

network.connect = function (host, port) {
    network.disconnect();
    tmpBuf = { "len": 0, "buffer": new Uint8Array(0) };
    var url = "ws://" + host + ":" + port;
    ws = new WebSocket(url);
    ws.binaryType = 'arraybuffer';
    ws.onopen = function () {
        // 握手
        var buffer = new Uint8Array(1);
        buffer[0] = 2 & 0xff;
        ws.send(buffer);

    };
    ws.onerror = function () { };
    ws.onclose = function () {
        clearInterval(heartbeatTimer);
        clearTimeout(heartbeatResTimeoutTimer);
        heartbeatResTimeoutTimer = null;
        msgCache.push({ "id": openOrClose.close, "data": null })
    };
    ws.onmessage = function (event) {
        handleMsg(new Uint8Array(event.data));
    };
}

network.onOpen = function (cb, self) {
    handlers[openOrClose.open] = cb.bind(self);
}

network.offOpen = function () {
    delete handlers[openOrClose.open];
}

network.onClose = function (cb, self) {
    handlers[openOrClose.close] = cb.bind(self);
}

network.offClose = function () {
    delete handlers[openOrClose.close];
}

network.addHandler = function (cmd, cb, self) {
    var cmdIndex = route.indexOf(cmd);
    if (cmdIndex === -1) {
        console.warn("cmd not exists:", cmd);
        return;
    }
    handlers[cmdIndex] = cb.bind(self);
}

network.removeHandler = function (cmd) {
    var cmdIndex = route.indexOf(cmd);
    if (cmdIndex === -1) {
        console.warn("cmd not exists:", cmd);
        return;
    }
    delete handlers[cmdIndex];
}


network.sendMsg = function (cmd, data) {
    var cmdIndex = route.indexOf(cmd);
    if (cmdIndex === -1) {
        console.warn("cmd not exists:", cmd);
        return;
    }
    var buffer = encode(cmdIndex, data);
    ws.send(buffer);
}

network.readMsg = function () {
    if (msgCache.length > 0) {
        var tmp = msgCache.shift();
        if (handlers[tmp.id]) {
            handlers[tmp.id](tmp.data);
        }
    }
}

network.disconnect = function () {
    if (ws) {
        ws.onopen = function () { };
        ws.onerror = function () { };
        ws.onclose = function () { };
        ws.onmessage = function () { };
        ws.close();
        ws = null;
        tmpBuf.len = 0;
        tmpBuf.buffer = new Uint8Array(0);
        msgCache = [];
    }
}

function encode(cmdIndex, data) {
    if (data === undefined) {
        data = null;
    }
    data = JSON.stringify(data);
    data = strencode(data);
    var msg_len = data.length + 3;
    var buffer = new Uint8Array(msg_len);
    var index = 0;
    buffer[index++] = 1 & 0xff;
    buffer[index++] = (cmdIndex >> 8) & 0xff;
    buffer[index++] = cmdIndex & 0xff;
    copyArray(buffer, index, data, 0, data.length);
    return buffer;
}


function handleMsg(data) {
    try {
        if (data[0] === 1) {
            var endBuf = new Uint8Array(data.length - 3);
            copyArray(endBuf, 0, data, 3, data.length - 3);
            msgCache.push({ "id": (data[1] << 8) | data[2], "data": JSON.parse(strdecode(endBuf)) })
        } else if (data[0] === 2) { //握手
            var endBuf = new Uint8Array(data.length - 1);
            copyArray(endBuf, 0, data, 1, data.length - 1);
            handshakeOver(JSON.parse(strdecode(endBuf)));
        } else if (data[0] === 3) {  // 心跳回调
            clearTimeout(heartbeatResTimeoutTimer);
            heartbeatResTimeoutTimer = null;
        }
    } catch (e) {
        console.log(e);
    }
}

function handshakeOver(msg) {
    route = msg.route;
    if (msg.heartbeat > 0) {
        heartbeatTimer = setInterval(sendHeartbeat, msg.heartbeat * 1000);
    }
    msgCache.push({ "id": openOrClose.open, "data": null })
}

function sendHeartbeat() {
    // 心跳
    var buffer = new Uint8Array(1);
    buffer[0] = 3 & 0xff;
    ws.send(buffer);

    if (heartbeatResTimeoutTimer === null) {
        heartbeatResTimeoutTimer = setTimeout(function () {
            network.disconnect();
        }, 5 * 1000);
    }
}


function strencode(str) {
    var byteArray = new Uint8Array(str.length * 3);
    var offset = 0;
    for (var i = 0; i < str.length; i++) {
        var charCode = str.charCodeAt(i);
        var codes = null;
        if (charCode <= 0x7f) {
            codes = [charCode];
        } else if (charCode <= 0x7ff) {
            codes = [0xc0 | (charCode >> 6), 0x80 | (charCode & 0x3f)];
        } else {
            codes = [0xe0 | (charCode >> 12), 0x80 | ((charCode & 0xfc0) >> 6), 0x80 | (charCode & 0x3f)];
        }
        for (var j = 0; j < codes.length; j++) {
            byteArray[offset] = codes[j];
            ++offset;
        }
    }
    var _buffer = new Uint8Array(offset);
    copyArray(_buffer, 0, byteArray, 0, offset);
    return _buffer;
};

function strdecode(bytes) {
    var array = [];
    var offset = 0;
    var charCode = 0;
    var end = bytes.length;
    while (offset < end) {
        if (bytes[offset] < 128) {
            charCode = bytes[offset];
            offset += 1;
        } else if (bytes[offset] < 224) {
            charCode = ((bytes[offset] & 0x3f) << 6) + (bytes[offset + 1] & 0x3f);
            offset += 2;
        } else {
            charCode = ((bytes[offset] & 0x0f) << 12) + ((bytes[offset + 1] & 0x3f) << 6) + (bytes[offset + 2] & 0x3f);
            offset += 3;
        }
        array.push(charCode);
    }
    return String.fromCharCode.apply(null, array);
};

function copyArray(dest, doffset, src, soffset, length) {
    for (var index = 0; index < length; index++) {
        dest[doffset++] = src[soffset++];
    }
};
