import { RoomMgr } from "./roomMgr";

const { ccclass, property } = cc._decorator;

@ccclass
export class RoomPrefab extends cc.Component {

    public id: number = 0;
    public password: string = "";

    init(data: { "id": number, "password": string, "name": string }) {
        this.id = data.id;
        this.password = data.password;
        this.node.getChildByName("name").getComponent(cc.Label).string = data.name;
        this.node.getChildByName("id").getComponent(cc.Label).string = "ID:" + data.id;
    }

    destroyMyself() {
        this.node.destroy();
    }

    onToggleClick() {
        RoomMgr.instance.onRoomPrefabClick(this);
    }
}
