import { ChatMgr } from "./chatMgr";
import { I_player_info } from "./roomMgr";


const { ccclass, property } = cc._decorator;

@ccclass
export class UserPrefab extends cc.Component {

    id: number = 0;
    username: string = "";

    init(data: I_player_info) {
        this.id = data.id;
        this.username = data.name;
        this.node.name = data.id.toString();
        this.node.getChildByName("name").getComponent(cc.Label).string = data.name;
        this.node.getChildByName("id").getComponent(cc.Label).string = "ID:" + data.id;
    }

    onToggleClick() {
        ChatMgr.instance.onUserPrefabClick(this);
    }
}
