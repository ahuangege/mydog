import { network } from "./network";
import { route } from "./route";
import { RoomMgr, I_joinRoomBack } from "./roomMgr";
import { ChatMgr } from "./chatMgr";


const { ccclass, property } = cc._decorator;

@ccclass
export class Main extends cc.Component {

    public static instance: Main = null;

    @property(cc.String)
    private host: string = "127.0.0.1";
    @property(cc.Integer)
    private port: number = 4001;

    private wrongInfoLabel: cc.Label = null;
    private chatServers: { "id": string, "name": string }[] = [];

    onLoad() {
        Main.instance = this;
        this.wrongInfoLabel = this.node.getChildByName("wrongInfo").getComponent(cc.Label);
    }

    start() {
        this.gateConnect();
    }

    private svr_onGateOpen() {
        network.addHandler(route.gate_main_login, this.svr_gateLoginBack, this);
        network.sendMsg(route.gate_main_login);
    }

    private svr_onGateClose() {
        this.setWrongInfo("服务器断开！5秒后重连!");
        this.scheduleOnce(() => {
            this.gateConnect();
        }, 5);
    }

    private svr_onConnectorOpen() {
        this.showRoomSelect(true);
    }

    private svr_onConnectorClose() {
        this.showChat(false);
        this.showRoomSelect(false);
        this.gateConnect();
    }

    private gateConnect() {
        network.connect(this.host, this.port);
        network.onOpen(this.svr_onGateOpen, this);
        network.onClose(this.svr_onGateClose, this);
    }


    // called every frame, uncomment this function to activate update callback
    update(dt) {
        network.readMsg();
    }

    svr_gateLoginBack(data: { "host": string, "port": number, "chat": { "id": string, "name": string }[] }) {
        this.chatServers = data.chat;
        network.connect(data.host, data.port);
        network.onOpen(this.svr_onConnectorOpen, this);
        network.onClose(this.svr_onConnectorClose, this);
    }


    setWrongInfo(str: string) {
        this.unschedule(this.wrongInfoHide);
        this.wrongInfoLabel.string = str;
        this.scheduleOnce(this.wrongInfoHide, 1.5);
    }
    private wrongInfoHide() {
        this.wrongInfoLabel.string = "";
    }

    showRoomSelect(show: boolean) {
        this.node.getChildByName("roomSelect").active = show;;
        if (show) {
            RoomMgr.instance.init(this.chatServers);
        }
    }

    showChat(show: boolean, data?: I_joinRoomBack) {
        this.node.getChildByName("chat").active = show;
        if (show) {
            ChatMgr.instance.init(data);
        }
    }

}
