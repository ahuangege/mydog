import { RoomMgr } from "./roomMgr";

const { ccclass, property } = cc._decorator;

@ccclass
export class ServerPrefab extends cc.Component {

    private serverId: string = "";
    @property(cc.Label)
    private serverNameLabel: cc.Label = null;

    init(data: { "id": string, "name": string }) {
        this.serverId = data.id;
        this.serverNameLabel.string = data.name;
    }

    onToggleClick() {
        RoomMgr.instance.onServerPrefabClick(this.serverId);
    }
}
