import { UserPrefab } from "./userPrefab";
import { network } from "./network";
import { route } from "./route";
import { I_joinRoomBack, I_player_info } from "./roomMgr";
import { Main } from "./main";


const { ccclass, property } = cc._decorator;

@ccclass
export class ChatMgr extends cc.Component {

    public static instance: ChatMgr = null;

    @property(cc.Node)
    public userParent: cc.Node = null;
    @property(cc.Prefab)
    public userPrefab: cc.Prefab = null;
    @property(cc.RichText)
    public chatContent: cc.RichText = null;
    
    private sendToAll: boolean = true;
    private nowUser: UserPrefab = null;
    private myId: number = 0;
    private nowUserLabel: cc.Label = null;
    private sendEditBox: cc.EditBox = null;

    onLoad() {
        ChatMgr.instance = this;
        this.nowUserLabel = cc.find("send/one/name", this.node).getComponent(cc.Label);
        this.sendEditBox = cc.find("send/content", this.node).getComponent(cc.EditBox);
    }

    start() {
        network.addHandler(route.onChat, this.svr_onChat, this);
        network.addHandler(route.onNewPlayer, this.svr_onNewPlayer, this);
        network.addHandler(route.onLeave, this.svr_onLeave, this);
    }

    init(data: I_joinRoomBack) {
        this.chatContent.string = "\n";
        this.myId = data.playerId;
        let node: cc.Node;
        let isFirst = true;
        for (var i = 0; i < data.players.length; i++) {
            node = this.newPlayer(data.players[i]);
            if (data.players[i].id == data.playerId) {
                this.node.getChildByName("info").getChildByName("info").getComponent(cc.Label).string =
                    "我的ID:" + data.playerId + "   服务器:" + data.serverName + "   房间ID:" + data.roomId + "   房间名:" + data.roomName;
            }
            if (isFirst) {
                isFirst = false;
                node.getComponent(cc.Toggle).isChecked = true;
                node.getComponent(UserPrefab).onToggleClick();
            }
        }
    }

    newPlayer(player: I_player_info) {
        let node = cc.instantiate(this.userPrefab);
        node.parent = this.userParent;
        node.getComponent(UserPrefab).init(player);
        return node;
    }

    sendMsg() {
        var str = this.sendEditBox.string;
        if (this.sendToAll) {
            network.sendMsg(route.chat_chatMain_send, { "type": 1, "msg": str });
            this.sendEditBox.string = "";
        } else if (cc.isValid(this.nowUser)) {
            network.sendMsg(route.chat_chatMain_send, { "type": 2, "msg": str, "toId": this.nowUser.id });
            this.sendEditBox.string = "";
        } else {
            Main.instance.setWrongInfo("玩家不能为空");
        }
    }

    svr_onChat(data: I_onChat_info) {
        if (data.type === 1) {
            var str = "";
            if (data.fromId === this.myId) {
                str += "<color=#0C8102>";
            } else {
                str += "<color=#A83AB8>"
            }
            str += data.from + "</c>:" + data.msg + "\n";
            this.chatContent.string += str;
        } else {
            var str = "";
            if (data.fromId === this.myId) {
                str += "<color=#0C8102>";
            } else {
                str += "<color=#A83AB8>"
            }
            str += data.from + "</c><color=FF0000>→</c>";
            if (data.toId === this.myId) {
                str += "<color=#0C8102>";
            } else {
                str += "<color=#A83AB8>";
            }
            str += data.to + "</c>:" + data.msg + "\n";
            this.chatContent.string += str;
        }

        if (this.chatContent.node.height > 2600) {
            var tmpStr = this.chatContent.string.substr(Math.floor(this.chatContent.string.length / 2));
            tmpStr = tmpStr.substr(tmpStr.indexOf("<color"));
            this.chatContent.string = tmpStr;
        }

    }

    svr_onNewPlayer(player: I_player_info) {
        this.newPlayer(player);
    }

    svr_onLeave(msg: { "id": number }) {
        var node = this.userParent.getChildByName(msg.id.toString());
        if (cc.isValid(node)) {
            node.destroy();
        }
    }

    onSendToAllToggleClick(toggle: cc.Toggle) {
        this.sendToAll = toggle.isChecked;
    }
    onLeaveBtnClick() {
        network.sendMsg(route.chat_chatMain_leaveRoom);
        Main.instance.showChat(false);
        Main.instance.showRoomSelect(true);
    }

    onUserPrefabClick(tmpUser: UserPrefab) {
        this.nowUser = tmpUser;
        this.nowUserLabel.string = tmpUser.username;
    }

    onDisable() {
        this.userParent.destroyAllChildren();
        this.chatContent.string = "";
        this.sendEditBox.string = "";
    }
}

export interface I_onChat_info {
    type: number,
    msg: string,
    fromId: number,
    from: string;
    toId: number;
    to: string;
}