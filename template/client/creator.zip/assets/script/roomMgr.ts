import { network } from "./network";
import { route } from "./route";
import { ServerPrefab } from "./serverPrefab";
import { Main } from "./main"
import { RoomPrefab } from "./roomPrefab"



const { ccclass, property } = cc._decorator;

@ccclass
export class RoomMgr extends cc.Component {

    public static instance: RoomMgr = null


    @property(cc.Prefab)
    private serverPrefab: cc.Prefab = null;
    @property(cc.Node)
    private serverParent: cc.Node = null;
    @property(cc.Prefab)
    private roomPrefab: cc.Prefab = null;
    @property(cc.Node)
    private roomParent: cc.Node = null;
    private nowServerId = "";
    private nowRoom: RoomPrefab = null;

    onLoad() {
        console.log("roomMgr onload")
        RoomMgr.instance = this;

    }

    init(chatServers: { "id": string, "name": string }[]) {
        network.addHandler(route.connector_connectorMain_getChatInfo, this.svr_getChatInfoBack, this)
        network.addHandler(route.connector_connectorMain_newRoom, this.svr_newRoomBack, this)
        network.addHandler(route.connector_connectorMain_joinRoom, this.svr_joinRoomBack, this)
        let node: cc.Node;
        let isFirst = true;
        for (let one of chatServers) {
            node = cc.instantiate(this.serverPrefab);
            node.parent = this.serverParent;
            node.getComponent(ServerPrefab).init(one);
            if (isFirst) {
                isFirst = false;
                node.getComponent(cc.Toggle).isChecked = true;
                node.getComponent(ServerPrefab).onToggleClick();
            }
        }
    }

    //聊天服务器的选择
    onServerPrefabClick(id: string) {
        this.nowServerId = id;
        this.roomParent.destroyAllChildren();
        network.sendMsg(route.connector_connectorMain_getChatInfo, { "id": id });
    }

    //房间的选择
    onRoomPrefabClick(tmpRoom: RoomPrefab) {
        this.nowRoom = tmpRoom;
    }


    svr_getChatInfoBack(data: { "rooms": { "id": number, "name": string, "password": string }[] }) {
        let node: cc.Node;
        let isFirst = true;
        for (let i = 0; i < data.rooms.length; i++) {
            node = cc.instantiate(this.roomPrefab);
            node.parent = this.roomParent;
            node.getComponent(RoomPrefab).init(data.rooms[i]);
            if (isFirst) {
                isFirst = false;
                node.getComponent(cc.Toggle).isChecked = true;
                node.getComponent(RoomPrefab).onToggleClick();
            }
        }
    }

    //新建房间
    onNewRoomBtnClick() {
        let myName = cc.find("myName/myName", this.node).getComponent(cc.EditBox).string.trim();
        let roomName = cc.find("newRoom/roomName", this.node).getComponent(cc.EditBox).string.trim();
        let password = cc.find("newRoom/password", this.node).getComponent(cc.EditBox).string.trim();
        if (myName === "") {
            Main.instance.setWrongInfo("昵称不能为空");
            return;
        }
        if (myName.indexOf(" ") !== -1) {
            Main.instance.setWrongInfo("昵称不可包含空格");
            return;
        }
        if (roomName === "") {
            Main.instance.setWrongInfo("房间名不能为空");
            return;
        }
        if (roomName.indexOf(" ") !== -1) {
            Main.instance.setWrongInfo("房间名不可包含空格");
            return;
        }
        if (password.indexOf(" ") !== -1) {
            Main.instance.setWrongInfo("密码不可包含空格");
            return;
        }

        network.sendMsg(route.connector_connectorMain_newRoom, { "id": this.nowServerId, "myName": myName, "roomName": roomName, "password": password });
    }

    svr_newRoomBack(data: I_joinRoomBack) {
        if (data.status === 0) {
            Main.instance.showChat(true, data);
            Main.instance.showRoomSelect(false);
        }
    }

    //加入房间
    onJoinRoomBtnClick() {
        if (!cc.isValid(this.nowRoom)) {
            Main.instance.setWrongInfo("房间不存在");
            return;
        }
        let myName = cc.find("myName/myName", this.node).getComponent(cc.EditBox).string.trim();
        let password = cc.find("newRoom/password", this.node).getComponent(cc.EditBox).string.trim();
        if (myName === "") {
            Main.instance.setWrongInfo("昵称不能为空");
            return;
        }
        if (myName.indexOf(" ") !== -1) {
            Main.instance.setWrongInfo("昵称不可包含空格");
            return;
        }
        if (password.indexOf(" ") !== -1) {
            Main.instance.setWrongInfo("密码不可包含空格");
            return;
        }
        if (this.nowRoom.password !== "" && password !== this.nowRoom.password) {
            Main.instance.setWrongInfo("密码错误");
            return;
        }
        network.sendMsg(route.connector_connectorMain_joinRoom, { "id": this.nowServerId, "roomId": this.nowRoom.id, "myName": myName, "password": password });
    }


    svr_joinRoomBack(data: I_joinRoomBack) {
        if (data.status === 0) {
            Main.instance.showChat(true, data);
            Main.instance.showRoomSelect(false);
        } else if (data.status === -1) {
            Main.instance.setWrongInfo("密码错误");
        } else if (data.status === -3) {
            Main.instance.setWrongInfo("房间不存在");
            this.nowRoom.destroyMyself();
        }
    }

    onDisable() {
        this.roomParent.destroyAllChildren();
        this.serverParent.destroyAllChildren();
    }
}

export interface I_joinRoomBack {
    status: number;
    roomName: string;
    roomId: number;
    playerId: number;
    serverId: string;
    serverName: string;
    players: I_player_info[];
}

/**
 * 玩家信息
 */
export interface I_player_info {
    "id": number,
    "uid": number,
    "sid": string,
    "name": string
}
