﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Main : MonoBehaviour
{
    public string host = "127.0.0.1";
    public int port = 4001;
    public Text infoText;
    public Text pongText;
    // Start is called before the first frame update
    void Start()
    {
        SocketClient.OnOpen(Svr_onOpen);
        SocketClient.OnClose(Svr_onClose);
        ConnectSvr();
    }

    // Update is called once per frame
    void Update()
    {
        SocketClient.ReadMsg();
    }

    void ConnectSvr()
    {
        print("connectSvr");
        infoText.text = "连接服务器中...";
        SocketClient.Connect(host, port);
    }

    void Svr_onOpen(string msg)
    {
        infoText.text = "服务器已连接";
        SocketClient.AddHandler(Cmd.connector_main_ping, Svr_pingBack);
    }

    void Svr_onClose(string msg)
    {
        print("close");
        infoText.text = "连接服务器中...";
        StartCoroutine(ConnectLater());
    }

    IEnumerator ConnectLater()
    {
        yield return new WaitForSeconds(2);
        ConnectSvr();
    }

    public void Btn_ping()
    {
        var msg = new Req_ping();
        msg.msg = "ping";
        SocketClient.SendMsg(Cmd.connector_main_ping, msg);
    }

    void Svr_pingBack(string msgStr)
    {
        var msg = JsonUtility.FromJson<Req_ping>(msgStr);
        pongText.text = msg.msg;
        pongText.transform.parent.gameObject.SetActive(true);
    }

    public void Btn_yes()
    {
        pongText.transform.parent.gameObject.SetActive(false);
    }
}

[Serializable]
public class Req_ping
{
    public string msg;
}

