﻿public class Cmd
{
    /// <summary>
    /// ping测试
    /// </summary>
    public const string connector_main_ping = "connector.main.ping";
}